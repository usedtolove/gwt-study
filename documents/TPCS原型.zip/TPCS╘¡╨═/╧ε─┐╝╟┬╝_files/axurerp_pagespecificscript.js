﻿
var PageName = '项目记录';
var PageId = '799e25e987e243fca3849facb27d7006'
var PageUrl = '项目记录.html'
document.title = '项目记录';
var PageNotes = 
{
"pageName":"项目记录",
"showNotesNames":"False",
"默认":"<p style=\"text-align:left;\"><span style=\"\">默认：先把 进行中的项目给列出来。<\/span><\/p><p style=\"text-align:left;\"><span style=\"\">不做分页，因为项目不会太多，可以在一页上全部展示<\/span><\/p><p style=\"text-align:left;\"><span style=\"\">点击 班级后，弹出 班级中参与项目的学员信息<\/span><\/p><p style=\"text-align:left;\"><span style=\"\">&nbsp;<\/span><\/p><p style=\"text-align:left;\"><span style=\"\">只有三种状态，默认是进行中， 处于此状态下的操作是： 结束，&nbsp; 明细， 删除[删除所有此班级下的学员的项目记录]<\/span><\/p><p style=\"text-align:left;\"><span style=\"\">结束后，项目状态变为 已完成， 处于此状态一的操作是：审核 ， 明细， 删除[删除所有此班级下的学员的项目记录，理论上不应该删除了]<\/span><\/p><p style=\"text-align:left;\"><span style=\"\">结束的项目，才能进行评分<\/span><\/p>"}
var $OnLoadVariable = '';

var $CSUM;

var hasQuery = false;
var query = window.location.hash.substring(1);
if (query.length > 0) hasQuery = true;
var vars = query.split("&");
for (var i = 0; i < vars.length; i++) {
    var pair = vars[i].split("=");
    if (pair[0].length > 0) eval("$" + pair[0] + " = decodeURIComponent(pair[1]);");
} 

if (hasQuery && $CSUM != 1) {
alert('Prototype Warning: The variable values were too long to pass to this page.\nIf you are using IE, using Firefox will support more data.');
}

function GetQuerystring() {
    return '#OnLoadVariable=' + encodeURIComponent($OnLoadVariable) + '&CSUM=1';
}

function PopulateVariables(value) {
    var d = new Date();
  value = value.replace(/\[\[OnLoadVariable\]\]/g, $OnLoadVariable);
  value = value.replace(/\[\[PageName\]\]/g, PageName);
  value = value.replace(/\[\[GenDay\]\]/g, '3');
  value = value.replace(/\[\[GenMonth\]\]/g, '6');
  value = value.replace(/\[\[GenMonthName\]\]/g, '六月');
  value = value.replace(/\[\[GenDayOfWeek\]\]/g, '星期一');
  value = value.replace(/\[\[GenYear\]\]/g, '2013');
  value = value.replace(/\[\[Day\]\]/g, d.getDate());
  value = value.replace(/\[\[Month\]\]/g, d.getMonth() + 1);
  value = value.replace(/\[\[MonthName\]\]/g, GetMonthString(d.getMonth()));
  value = value.replace(/\[\[DayOfWeek\]\]/g, GetDayString(d.getDay()));
  value = value.replace(/\[\[Year\]\]/g, d.getFullYear());
  return value;
}

function OnLoad(e) {

}

var u370 = document.getElementById('u370');

var u564 = document.getElementById('u564');

var u318 = document.getElementById('u318');

var u526 = document.getElementById('u526');

var u167 = document.getElementById('u167');

var u299 = document.getElementById('u299');

var u465 = document.getElementById('u465');
gv_vAlignTable['u465'] = 'top';
var u36 = document.getElementById('u36');
gv_vAlignTable['u36'] = 'center';
var u180 = document.getElementById('u180');
gv_vAlignTable['u180'] = 'top';
var u613 = document.getElementById('u613');
gv_vAlignTable['u613'] = 'top';
var u609 = document.getElementById('u609');
gv_vAlignTable['u609'] = 'top';
var u400 = document.getElementById('u400');

var u488 = document.getElementById('u488');

var u373 = document.getElementById('u373');
gv_vAlignTable['u373'] = 'top';
var u216 = document.getElementById('u216');
gv_vAlignTable['u216'] = 'top';
var u194 = document.getElementById('u194');
gv_vAlignTable['u194'] = 'center';
var u514 = document.getElementById('u514');

var u492 = document.getElementById('u492');

var u333 = document.getElementById('u333');
gv_vAlignTable['u333'] = 'top';
var u569 = document.getElementById('u569');
gv_vAlignTable['u569'] = 'top';
var u97 = document.getElementById('u97');
gv_vAlignTable['u97'] = 'top';
var u152 = document.getElementById('u152');
gv_vAlignTable['u152'] = 'top';
var u450 = document.getElementById('u450');

var u587 = document.getElementById('u587');
gv_vAlignTable['u587'] = 'top';
var u517 = document.getElementById('u517');
gv_vAlignTable['u517'] = 'top';
var u347 = document.getElementById('u347');
gv_vAlignTable['u347'] = 'top';
var u78 = document.getElementById('u78');

var u434 = document.getElementById('u434');

var u166 = document.getElementById('u166');

var u298 = document.getElementById('u298');
gv_vAlignTable['u298'] = 'top';
var u464 = document.getElementById('u464');

var u139 = document.getElementById('u139');

var u201 = document.getElementById('u201');

var u1 = document.getElementById('u1');
gv_vAlignTable['u1'] = 'center';
var u498 = document.getElementById('u498');

var u215 = document.getElementById('u215');

var u193 = document.getElementById('u193');

var u11 = document.getElementById('u11');

var u413 = document.getElementById('u413');
gv_vAlignTable['u413'] = 'top';
var u332 = document.getElementById('u332');

var u563 = document.getElementById('u563');
gv_vAlignTable['u563'] = 'top';
var u131 = document.getElementById('u131');

var u151 = document.getElementById('u151');

var u586 = document.getElementById('u586');

var u225 = document.getElementById('u225');

var u346 = document.getElementById('u346');

var u72 = document.getElementById('u72');

var u388 = document.getElementById('u388');

var u165 = document.getElementById('u165');

var u463 = document.getElementById('u463');
gv_vAlignTable['u463'] = 'top';
var u138 = document.getElementById('u138');
gv_vAlignTable['u138'] = 'top';
var u264 = document.getElementById('u264');
gv_vAlignTable['u264'] = 'top';
var u100 = document.getElementById('u100');

var u486 = document.getElementById('u486');

var u477 = document.getElementById('u477');
gv_vAlignTable['u477'] = 'top';
var u214 = document.getElementById('u214');
gv_vAlignTable['u214'] = 'top';
var u125 = document.getElementById('u125');

var u67 = document.getElementById('u67');

var u269 = document.getElementById('u269');

var u331 = document.getElementById('u331');
gv_vAlignTable['u331'] = 'top';
var u378 = document.getElementById('u378');

var u150 = document.getElementById('u150');
gv_vAlignTable['u150'] = 'top';
var u287 = document.getElementById('u287');

var u607 = document.getElementById('u607');
gv_vAlignTable['u607'] = 'top';
var u585 = document.getElementById('u585');
gv_vAlignTable['u585'] = 'top';
var u515 = document.getElementById('u515');
gv_vAlignTable['u515'] = 'top';
var u48 = document.getElementById('u48');
gv_vAlignTable['u48'] = 'center';
var u345 = document.getElementById('u345');
gv_vAlignTable['u345'] = 'top';
var u24 = document.getElementById('u24');

var u80 = document.getElementById('u80');

var u462 = document.getElementById('u462');

var u376 = document.getElementById('u376');

var u261 = document.getElementById('u261');

var u300 = document.getElementById('u300');
gv_vAlignTable['u300'] = 'top';
var u476 = document.getElementById('u476');

var u449 = document.getElementById('u449');
gv_vAlignTable['u449'] = 'top';
var u85 = document.getElementById('u85');
gv_vAlignTable['u85'] = 'top';
var u319 = document.getElementById('u319');
gv_vAlignTable['u319'] = 'center';
var u268 = document.getElementById('u268');
gv_vAlignTable['u268'] = 'top';
var u330 = document.getElementById('u330');

var u286 = document.getElementById('u286');
gv_vAlignTable['u286'] = 'top';
var u606 = document.getElementById('u606');

var u584 = document.getElementById('u584');

var u557 = document.getElementById('u557');
gv_vAlignTable['u557'] = 'top';
var u42 = document.getElementById('u42');

var u419 = document.getElementById('u419');
gv_vAlignTable['u419'] = 'top';
var u163 = document.getElementById('u163');
gv_vAlignTable['u163'] = 'top';
var u41 = document.getElementById('u41');

var u461 = document.getElementById('u461');
gv_vAlignTable['u461'] = 'top';
var u95 = document.getElementById('u95');
gv_vAlignTable['u95'] = 'top';
var u359 = document.getElementById('u359');
gv_vAlignTable['u359'] = 'top';
var u590 = document.getElementById('u590');

var u177 = document.getElementById('u177');

var u475 = document.getElementById('u475');
gv_vAlignTable['u475'] = 'top';
var u37 = document.getElementById('u37');

var u93 = document.getElementById('u93');
gv_vAlignTable['u93'] = 'top';
var u112 = document.getElementById('u112');
gv_vAlignTable['u112'] = 'top';
var u410 = document.getElementById('u410');

var u335 = document.getElementById('u335');
gv_vAlignTable['u335'] = 'top';
var u159 = document.getElementById('u159');

var u307 = document.getElementById('u307');

var u285 = document.getElementById('u285');

var u438 = document.getElementById('u438');

var u126 = document.getElementById('u126');
gv_vAlignTable['u126'] = 'top';
var u50 = document.getElementById('u50');
gv_vAlignTable['u50'] = 'center';
var u424 = document.getElementById('u424');

var u343 = document.getElementById('u343');
gv_vAlignTable['u343'] = 'top';
var u579 = document.getElementById('u579');
gv_vAlignTable['u579'] = 'top';
var u162 = document.getElementById('u162');
gv_vAlignTable['u162'] = 'center';
var u541 = document.getElementById('u541');
gv_vAlignTable['u541'] = 'top';
var u442 = document.getElementById('u442');

var u597 = document.getElementById('u597');
gv_vAlignTable['u597'] = 'top';
var u357 = document.getElementById('u357');
gv_vAlignTable['u357'] = 'top';
var u79 = document.getElementById('u79');
gv_vAlignTable['u79'] = 'top';
var u176 = document.getElementById('u176');

u176.style.cursor = 'pointer';
if (bIE) u176.attachEvent("onclick", Clicku176);
else u176.addEventListener("click", Clicku176, true);
function Clicku176(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u156','','fade',500);

}

}

var u55 = document.getElementById('u55');
gv_vAlignTable['u55'] = 'center';
var u474 = document.getElementById('u474');

var u149 = document.getElementById('u149');

var u528 = document.getElementById('u528');

var u111 = document.getElementById('u111');

u111.style.cursor = 'pointer';
if (bIE) u111.attachEvent("onclick", Clicku111);
else u111.addEventListener("click", Clicku111, true);
function Clicku111(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u190','','fade',500);

}

}

var u425 = document.getElementById('u425');
gv_vAlignTable['u425'] = 'top';
var u543 = document.getElementById('u543');
gv_vAlignTable['u543'] = 'top';
var u306 = document.getElementById('u306');
gv_vAlignTable['u306'] = 'top';
var u284 = document.getElementById('u284');
gv_vAlignTable['u284'] = 'top';
var u604 = document.getElementById('u604');

var u12 = document.getElementById('u12');
gv_vAlignTable['u12'] = 'center';
var u423 = document.getElementById('u423');
gv_vAlignTable['u423'] = 'top';
var u342 = document.getElementById('u342');

var u578 = document.getElementById('u578');

var u582 = document.getElementById('u582');

var u161 = document.getElementById('u161');

var u540 = document.getElementById('u540');

var u596 = document.getElementById('u596');

var u437 = document.getElementById('u437');
gv_vAlignTable['u437'] = 'top';
var u356 = document.getElementById('u356');

var u372 = document.getElementById('u372');

var u175 = document.getElementById('u175');

var u568 = document.getElementById('u568');

var u229 = document.getElementById('u229');

var u148 = document.getElementById('u148');
gv_vAlignTable['u148'] = 'top';
var u110 = document.getElementById('u110');

var u61 = document.getElementById('u61');

u61.style.cursor = 'pointer';
if (bIE) u61.attachEvent("onclick", Clicku61);
else u61.addEventListener("click", Clicku61, true);
function Clicku61(e)
{
windowEvent = e;


if (true) {

	self.location.href="登录.html" + GetQuerystring();

}

}
gv_vAlignTable['u61'] = 'top';
var u305 = document.getElementById('u305');

var u283 = document.getElementById('u283');

var u20 = document.getElementById('u20');

var u124 = document.getElementById('u124');
gv_vAlignTable['u124'] = 'top';
var u279 = document.getElementById('u279');

var u458 = document.getElementById('u458');

var u241 = document.getElementById('u241');

var u160 = document.getElementById('u160');
gv_vAlignTable['u160'] = 'center';
var u297 = document.getElementById('u297');

var u8 = document.getElementById('u8');
gv_vAlignTable['u8'] = 'top';
var u472 = document.getElementById('u472');

var u49 = document.getElementById('u49');

var u312 = document.getElementById('u312');
gv_vAlignTable['u312'] = 'top';
var u25 = document.getElementById('u25');

var u81 = document.getElementById('u81');
gv_vAlignTable['u81'] = 'top';
var u553 = document.getElementById('u553');
gv_vAlignTable['u553'] = 'top';
var u228 = document.getElementById('u228');
gv_vAlignTable['u228'] = 'top';
var u374 = document.getElementById('u374');

var u567 = document.getElementById('u567');
gv_vAlignTable['u567'] = 'top';
var u304 = document.getElementById('u304');
gv_vAlignTable['u304'] = 'top';
var u282 = document.getElementById('u282');

var u76 = document.getElementById('u76');

var u123 = document.getElementById('u123');

var u278 = document.getElementById('u278');

if (bIE) u278.attachEvent("onmouseover", MouseOveru278);
else u278.addEventListener("mouseover", MouseOveru278, true);
function MouseOveru278(e)
{
windowEvent = e;

if (!IsTrueMouseOver('u278',e)) return;
if (true) {

	SetPanelVisibility('u279','','fade',500);

}

}

if (bIE) u278.attachEvent("onmouseout", MouseOutu278);
else u278.addEventListener("mouseout", MouseOutu278, true);
function MouseOutu278(e)
{
windowEvent = e;

if (!IsTrueMouseOut('u278',e)) return;
if (true) {

	SetPanelVisibility('u279','hidden','fade',500);

}

}

var u501 = document.getElementById('u501');
gv_vAlignTable['u501'] = 'top';
var u240 = document.getElementById('u240');
gv_vAlignTable['u240'] = 'top';
var u296 = document.getElementById('u296');
gv_vAlignTable['u296'] = 'top';
var u202 = document.getElementById('u202');
gv_vAlignTable['u202'] = 'top';
var u137 = document.getElementById('u137');

var u435 = document.getElementById('u435');
gv_vAlignTable['u435'] = 'top';
var u33 = document.getElementById('u33');

var u254 = document.getElementById('u254');
gv_vAlignTable['u254'] = 'top';
var u173 = document.getElementById('u173');
gv_vAlignTable['u173'] = 'top';
var u552 = document.getElementById('u552');

var u471 = document.getElementById('u471');
gv_vAlignTable['u471'] = 'top';
var u536 = document.getElementById('u536');

var u566 = document.getElementById('u566');

var u303 = document.getElementById('u303');

var u281 = document.getElementById('u281');
gv_vAlignTable['u281'] = 'center';
var u63 = document.getElementById('u63');

u63.style.cursor = 'pointer';
if (bIE) u63.attachEvent("onclick", Clicku63);
else u63.addEventListener("click", Clicku63, true);
function Clicku63(e)
{
windowEvent = e;


if (true) {

	self.location.href="个人信息（非导航项）.html" + GetQuerystring();

}

}
gv_vAlignTable['u63'] = 'top';
var u122 = document.getElementById('u122');

var u358 = document.getElementById('u358');

var u420 = document.getElementById('u420');

var u5 = document.getElementById('u5');

var u391 = document.getElementById('u391');
gv_vAlignTable['u391'] = 'top';
var u317 = document.getElementById('u317');
gv_vAlignTable['u317'] = 'center';
var u295 = document.getElementById('u295');

var u615 = document.getElementById('u615');
gv_vAlignTable['u615'] = 'top';
var u136 = document.getElementById('u136');
gv_vAlignTable['u136'] = 'top';
var u51 = document.getElementById('u51');
gv_vAlignTable['u51'] = 'top';
var u290 = document.getElementById('u290');
gv_vAlignTable['u290'] = 'top';
var u109 = document.getElementById('u109');

var u253 = document.getElementById('u253');

var u172 = document.getElementById('u172');
gv_vAlignTable['u172'] = 'center';
var u529 = document.getElementById('u529');
gv_vAlignTable['u529'] = 'top';
var u470 = document.getElementById('u470');

var u267 = document.getElementById('u267');

var u344 = document.getElementById('u344');

var u565 = document.getElementById('u565');
gv_vAlignTable['u565'] = 'top';
var u302 = document.getElementById('u302');
gv_vAlignTable['u302'] = 'top';
var u280 = document.getElementById('u280');

var u121 = document.getElementById('u121');

u121.style.cursor = 'pointer';
if (bIE) u121.attachEvent("onclick", Clicku121);
else u121.addEventListener("click", Clicku121, true);
function Clicku121(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u166','','fade',500);

}

}

var u500 = document.getElementById('u500');

var u594 = document.getElementById('u594');

var u525 = document.getElementById('u525');
gv_vAlignTable['u525'] = 'top';
var u316 = document.getElementById('u316');

var u294 = document.getElementById('u294');
gv_vAlignTable['u294'] = 'top';
var u614 = document.getElementById('u614');

var u135 = document.getElementById('u135');

var u433 = document.getElementById('u433');
gv_vAlignTable['u433'] = 'top';
var u108 = document.getElementById('u108');
gv_vAlignTable['u108'] = 'top';
var u573 = document.getElementById('u573');
gv_vAlignTable['u573'] = 'top';
var u252 = document.getElementById('u252');
gv_vAlignTable['u252'] = 'top';
var u171 = document.getElementById('u171');

var u550 = document.getElementById('u550');

var u519 = document.getElementById('u519');
gv_vAlignTable['u519'] = 'top';
var u402 = document.getElementById('u402');

var u398 = document.getElementById('u398');

var u266 = document.getElementById('u266');
gv_vAlignTable['u266'] = 'top';
var u64 = document.getElementById('u64');

u64.style.cursor = 'pointer';
if (bIE) u64.attachEvent("onclick", Clicku64);
else u64.addEventListener("click", Clicku64, true);
function Clicku64(e)
{
windowEvent = e;


if (true) {

	self.location.href="上传头象（非导航项）.html" + GetQuerystring();

}

}

var u580 = document.getElementById('u580');

var u239 = document.getElementById('u239');

var u301 = document.getElementById('u301');

var u618 = document.getElementById('u618');

var u274 = document.getElementById('u274');

var u120 = document.getElementById('u120');

var u2 = document.getElementById('u2');

var u315 = document.getElementById('u315');

var u293 = document.getElementById('u293');

var u21 = document.getElementById('u21');
gv_vAlignTable['u21'] = 'center';
var u134 = document.getElementById('u134');
gv_vAlignTable['u134'] = 'top';
var u513 = document.getElementById('u513');
gv_vAlignTable['u513'] = 'top';
var u288 = document.getElementById('u288');
gv_vAlignTable['u288'] = 'top';
var u251 = document.getElementById('u251');

var u170 = document.getElementById('u170');
gv_vAlignTable['u170'] = 'center';
var u164 = document.getElementById('u164');

u164.style.cursor = 'pointer';
if (bIE) u164.attachEvent("onclick", Clicku164);
else u164.addEventListener("click", Clicku164, true);
function Clicku164(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u156','hidden','none',500);

}

}

var u446 = document.getElementById('u446');

var u429 = document.getElementById('u429');
gv_vAlignTable['u429'] = 'top';
var u265 = document.getElementById('u265');

var u82 = document.getElementById('u82');

var u16 = document.getElementById('u16');
gv_vAlignTable['u16'] = 'center';
var u238 = document.getElementById('u238');
gv_vAlignTable['u238'] = 'top';
var u200 = document.getElementById('u200');
gv_vAlignTable['u200'] = 'top';
var u390 = document.getElementById('u390');

var u539 = document.getElementById('u539');
gv_vAlignTable['u539'] = 'top';
var u577 = document.getElementById('u577');
gv_vAlignTable['u577'] = 'top';
var u554 = document.getElementById('u554');

var u314 = document.getElementById('u314');
gv_vAlignTable['u314'] = 'top';
var u292 = document.getElementById('u292');
gv_vAlignTable['u292'] = 'top';
var u77 = document.getElementById('u77');
gv_vAlignTable['u77'] = 'top';
var u18 = document.getElementById('u18');
gv_vAlignTable['u18'] = 'center';
var u369 = document.getElementById('u369');
gv_vAlignTable['u369'] = 'top';
var u431 = document.getElementById('u431');
gv_vAlignTable['u431'] = 'top';
var u250 = document.getElementById('u250');
gv_vAlignTable['u250'] = 'top';
var u387 = document.getElementById('u387');
gv_vAlignTable['u387'] = 'top';
var u147 = document.getElementById('u147');

var u58 = document.getElementById('u58');

var u445 = document.getElementById('u445');
gv_vAlignTable['u445'] = 'top';
var u34 = document.getElementById('u34');
gv_vAlignTable['u34'] = 'center';
var u90 = document.getElementById('u90');

var u562 = document.getElementById('u562');

var u408 = document.getElementById('u408');

var u518 = document.getElementById('u518');

var u576 = document.getElementById('u576');

var u549 = document.getElementById('u549');
gv_vAlignTable['u549'] = 'top';
var u213 = document.getElementById('u213');

var u191 = document.getElementById('u191');

var u368 = document.getElementById('u368');

var u430 = document.getElementById('u430');

var u102 = document.getElementById('u102');
gv_vAlignTable['u102'] = 'top';
var u259 = document.getElementById('u259');

var u603 = document.getElementById('u603');
gv_vAlignTable['u603'] = 'top';
var u448 = document.getElementById('u448');

var u146 = document.getElementById('u146');
gv_vAlignTable['u146'] = 'top';
var u52 = document.getElementById('u52');

var u444 = document.getElementById('u444');

var u119 = document.getElementById('u119');
gv_vAlignTable['u119'] = 'top';
var u263 = document.getElementById('u263');

var u432 = document.getElementById('u432');

var u574 = document.getElementById('u574');

var u277 = document.getElementById('u277');
gv_vAlignTable['u277'] = 'top';
var u14 = document.getElementById('u14');
gv_vAlignTable['u14'] = 'center';
var u575 = document.getElementById('u575');
gv_vAlignTable['u575'] = 'top';
var u47 = document.getElementById('u47');

var u548 = document.getElementById('u548');

var u212 = document.getElementById('u212');
gv_vAlignTable['u212'] = 'top';
var u190 = document.getElementById('u190');

var u510 = document.getElementById('u510');

var u581 = document.getElementById('u581');
gv_vAlignTable['u581'] = 'top';
var u94 = document.getElementById('u94');

var u385 = document.getElementById('u385');
gv_vAlignTable['u385'] = 'top';
var u321 = document.getElementById('u321');
gv_vAlignTable['u321'] = 'center';
var u28 = document.getElementById('u28');
gv_vAlignTable['u28'] = 'center';
var u145 = document.getElementById('u145');

var u524 = document.getElementById('u524');

var u443 = document.getElementById('u443');
gv_vAlignTable['u443'] = 'top';
var u118 = document.getElementById('u118');

u118.style.cursor = 'pointer';
if (bIE) u118.attachEvent("onclick", Clicku118);
else u118.addEventListener("click", Clicku118, true);
function Clicku118(e)
{
windowEvent = e;


if ((GetCheckState('u118')) == (true)) {

	SetPanelVisibility('u177','','fade',500);

}
else
if ((GetCheckState('u118')) == (false)) {

	SetPanelVisibility('u177','hidden','fade',500);

}

}

var u262 = document.getElementById('u262');
gv_vAlignTable['u262'] = 'top';
var u560 = document.getElementById('u560');

var u325 = document.getElementById('u325');
gv_vAlignTable['u325'] = 'top';
var u457 = document.getElementById('u457');
gv_vAlignTable['u457'] = 'top';
var u276 = document.getElementById('u276');

var u89 = document.getElementById('u89');
gv_vAlignTable['u89'] = 'top';
var u186 = document.getElementById('u186');
gv_vAlignTable['u186'] = 'top';
var u249 = document.getElementById('u249');

var u386 = document.getElementById('u386');

var u211 = document.getElementById('u211');

var u130 = document.getElementById('u130');
gv_vAlignTable['u130'] = 'top';
var u489 = document.getElementById('u489');
gv_vAlignTable['u489'] = 'top';
var u406 = document.getElementById('u406');

var u384 = document.getElementById('u384');

var u22 = document.getElementById('u22');

var u144 = document.getElementById('u144');
gv_vAlignTable['u144'] = 'top';
var u523 = document.getElementById('u523');
gv_vAlignTable['u523'] = 'top';
var u311 = document.getElementById('u311');

var u227 = document.getElementById('u227');

var u605 = document.getElementById('u605');
gv_vAlignTable['u605'] = 'top';
var u537 = document.getElementById('u537');
gv_vAlignTable['u537'] = 'top';
var u456 = document.getElementById('u456');

var u275 = document.getElementById('u275');

var u17 = document.getElementById('u17');

u17.style.cursor = 'pointer';
if (bIE) u17.attachEvent("onclick", Clicku17);
else u17.addEventListener("click", Clicku17, true);
function Clicku17(e)
{
windowEvent = e;


if ((GetGlobalVariableValue('$OnLoadVariable')) == ('')) {

	SetPanelVisibility('u41','hidden','fade',500);

	SetPanelState('u19', 'pd1u19','none','',500,'none','',500);

	MoveWidgetBy('u24',0,-440,'easeOutBounce',500);

SetGlobalVariableValue('$OnLoadVariable', '1');

}
else
if ((GetGlobalVariableValue('$OnLoadVariable')) == ('1')) {

	SetPanelVisibility('u41','','fade',500);

	SetPanelState('u19', 'pd0u19','none','',500,'none','',500);

	MoveWidgetBy('u24',0,440,'easeOutBounce',500);

SetGlobalVariableValue('$OnLoadVariable', '');

}

}

var u248 = document.getElementById('u248');
gv_vAlignTable['u248'] = 'top';
var u210 = document.getElementById('u210');
gv_vAlignTable['u210'] = 'top';
var u502 = document.getElementById('u502');

var u107 = document.getElementById('u107');

var u405 = document.getElementById('u405');
gv_vAlignTable['u405'] = 'top';
var u383 = document.getElementById('u383');
gv_vAlignTable['u383'] = 'top';
var u30 = document.getElementById('u30');
gv_vAlignTable['u30'] = 'center';
var u224 = document.getElementById('u224');
gv_vAlignTable['u224'] = 'top';
var u143 = document.getElementById('u143');

var u379 = document.getElementById('u379');
gv_vAlignTable['u379'] = 'top';
var u341 = document.getElementById('u341');
gv_vAlignTable['u341'] = 'top';
var u260 = document.getElementById('u260');
gv_vAlignTable['u260'] = 'top';
var u397 = document.getElementById('u397');
gv_vAlignTable['u397'] = 'top';
var u9 = document.getElementById('u9');

var u15 = document.getElementById('u15');

var u157 = document.getElementById('u157');

var u59 = document.getElementById('u59');
gv_vAlignTable['u59'] = 'center';
var u455 = document.getElementById('u455');
gv_vAlignTable['u455'] = 'top';
var u189 = document.getElementById('u189');

u189.style.cursor = 'pointer';
if (bIE) u189.attachEvent("onclick", Clicku189);
else u189.addEventListener("click", Clicku189, true);
function Clicku189(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u315','','fade',500);

}

}

var u35 = document.getElementById('u35');

var u91 = document.getElementById('u91');
gv_vAlignTable['u91'] = 'top';
var u328 = document.getElementById('u328');

var u44 = document.getElementById('u44');

var u616 = document.getElementById('u616');

u616.style.cursor = 'pointer';
if (bIE) u616.attachEvent("onclick", Clicku616);
else u616.addEventListener("click", Clicku616, true);
function Clicku616(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u315','hidden','fade',500);

}

}

var u207 = document.getElementById('u207');

var u106 = document.getElementById('u106');
gv_vAlignTable['u106'] = 'top';
var u411 = document.getElementById('u411');
gv_vAlignTable['u411'] = 'top';
var u404 = document.getElementById('u404');

var u382 = document.getElementById('u382');

var u559 = document.getElementById('u559');
gv_vAlignTable['u559'] = 'top';
var u223 = document.getElementById('u223');

var u142 = document.getElementById('u142');
gv_vAlignTable['u142'] = 'top';
var u86 = document.getElementById('u86');

var u340 = document.getElementById('u340');

var u396 = document.getElementById('u396');

var u237 = document.getElementById('u237');

var u156 = document.getElementById('u156');

var u535 = document.getElementById('u535');
gv_vAlignTable['u535'] = 'top';
var u436 = document.getElementById('u436');

var u188 = document.getElementById('u188');
gv_vAlignTable['u188'] = 'top';
var u354 = document.getElementById('u354');

var u273 = document.getElementById('u273');
gv_vAlignTable['u273'] = 'top';
var u532 = document.getElementById('u532');

var u571 = document.getElementById('u571');
gv_vAlignTable['u571'] = 'top';
var u593 = document.getElementById('u593');
gv_vAlignTable['u593'] = 'top';
var u105 = document.getElementById('u105');
gv_vAlignTable['u105'] = 'top';
var u544 = document.getElementById('u544');

var u403 = document.getElementById('u403');
gv_vAlignTable['u403'] = 'top';
var u381 = document.getElementById('u381');
gv_vAlignTable['u381'] = 'top';
var u326 = document.getElementById('u326');

var u222 = document.getElementById('u222');
gv_vAlignTable['u222'] = 'top';
var u236 = document.getElementById('u236');
gv_vAlignTable['u236'] = 'top';
var u520 = document.getElementById('u520');

var u6 = document.getElementById('u6');

var u422 = document.getElementById('u422');

var u611 = document.getElementById('u611');
gv_vAlignTable['u611'] = 'top';
var u417 = document.getElementById('u417');
gv_vAlignTable['u417'] = 'top';
var u395 = document.getElementById('u395');
gv_vAlignTable['u395'] = 'top';
var u527 = document.getElementById('u527');
gv_vAlignTable['u527'] = 'top';
var u29 = document.getElementById('u29');

var u155 = document.getElementById('u155');

var u534 = document.getElementById('u534');

var u209 = document.getElementById('u209');

var u353 = document.getElementById('u353');
gv_vAlignTable['u353'] = 'top';
var u272 = document.getElementById('u272');

var u570 = document.getElementById('u570');

var u592 = document.getElementById('u592');

var u494 = document.getElementById('u494');

var u46 = document.getElementById('u46');
gv_vAlignTable['u46'] = 'top';
var u499 = document.getElementById('u499');
gv_vAlignTable['u499'] = 'top';
var u104 = document.getElementById('u104');

var u56 = document.getElementById('u56');
gv_vAlignTable['u56'] = 'top';
var u380 = document.getElementById('u380');

var u221 = document.getElementById('u221');

var u600 = document.getElementById('u600');

var u473 = document.getElementById('u473');
gv_vAlignTable['u473'] = 'top';
var u512 = document.getElementById('u512');

var u412 = document.getElementById('u412');

var u416 = document.getElementById('u416');

var u394 = document.getElementById('u394');

var u235 = document.getElementById('u235');

var u13 = document.getElementById('u13');

var u208 = document.getElementById('u208');
gv_vAlignTable['u208'] = 'top';
var u551 = document.getElementById('u551');
gv_vAlignTable['u551'] = 'top';
var u352 = document.getElementById('u352');

var u271 = document.getElementById('u271');
gv_vAlignTable['u271'] = 'top';
var u595 = document.getElementById('u595');
gv_vAlignTable['u595'] = 'top';
var u508 = document.getElementById('u508');

var u174 = document.getElementById('u174');

u174.style.cursor = 'pointer';
if (bIE) u174.attachEvent("onclick", Clicku174);
else u174.addEventListener("click", Clicku174, true);
function Clicku174(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u166','hidden','none',500);

}

}

var u363 = document.getElementById('u363');
gv_vAlignTable['u363'] = 'top';
var u74 = document.getElementById('u74');

var u366 = document.getElementById('u366');

var u98 = document.getElementById('u98');

var u103 = document.getElementById('u103');
gv_vAlignTable['u103'] = 'top';
var u339 = document.getElementById('u339');
gv_vAlignTable['u339'] = 'top';
var u401 = document.getElementById('u401');
gv_vAlignTable['u401'] = 'top';
var u158 = document.getElementById('u158');
gv_vAlignTable['u158'] = 'center';
var u220 = document.getElementById('u220');
gv_vAlignTable['u220'] = 'top';
var u3 = document.getElementById('u3');

var u117 = document.getElementById('u117');
gv_vAlignTable['u117'] = 'top';
var u415 = document.getElementById('u415');
gv_vAlignTable['u415'] = 'top';
var u393 = document.getElementById('u393');
gv_vAlignTable['u393'] = 'top';
var u31 = document.getElementById('u31');

var u234 = document.getElementById('u234');
gv_vAlignTable['u234'] = 'top';
var u19 = document.getElementById('u19');

var u591 = document.getElementById('u591');
gv_vAlignTable['u591'] = 'top';
var u547 = document.getElementById('u547');
gv_vAlignTable['u547'] = 'top';
var u351 = document.getElementById('u351');
gv_vAlignTable['u351'] = 'top';
var u270 = document.getElementById('u270');
gv_vAlignTable['u270'] = 'top';
var u546 = document.getElementById('u546');

var u199 = document.getElementById('u199');

var u365 = document.getElementById('u365');
gv_vAlignTable['u365'] = 'top';
var u92 = document.getElementById('u92');

var u26 = document.getElementById('u26');
gv_vAlignTable['u26'] = 'center';
var u338 = document.getElementById('u338');

var u54 = document.getElementById('u54');

var u418 = document.getElementById('u418');

var u116 = document.getElementById('u116');

var u533 = document.getElementById('u533');
gv_vAlignTable['u533'] = 'top';
var u414 = document.getElementById('u414');

var u392 = document.getElementById('u392');

var u233 = document.getElementById('u233');

var u469 = document.getElementById('u469');
gv_vAlignTable['u469'] = 'top';
var u87 = document.getElementById('u87');
gv_vAlignTable['u87'] = 'top';
var u426 = document.getElementById('u426');

var u355 = document.getElementById('u355');
gv_vAlignTable['u355'] = 'top';
var u350 = document.getElementById('u350');

var u487 = document.getElementById('u487');
gv_vAlignTable['u487'] = 'top';
var u308 = document.getElementById('u308');
gv_vAlignTable['u308'] = 'top';
var u247 = document.getElementById('u247');

var u68 = document.getElementById('u68');
gv_vAlignTable['u68'] = 'top';
var u545 = document.getElementById('u545');
gv_vAlignTable['u545'] = 'top';
var u198 = document.getElementById('u198');

var u364 = document.getElementById('u364');

var u101 = document.getElementById('u101');
gv_vAlignTable['u101'] = 'top';
var u561 = document.getElementById('u561');
gv_vAlignTable['u561'] = 'top';
var u0 = document.getElementById('u0');

var u245 = document.getElementById('u245');

var u375 = document.getElementById('u375');
gv_vAlignTable['u375'] = 'top';
var u115 = document.getElementById('u115');
gv_vAlignTable['u115'] = 'top';
var u348 = document.getElementById('u348');

var u608 = document.getElementById('u608');

var u313 = document.getElementById('u313');

var u232 = document.getElementById('u232');
gv_vAlignTable['u232'] = 'top';
var u468 = document.getElementById('u468');

var u530 = document.getElementById('u530');

var u427 = document.getElementById('u427');
gv_vAlignTable['u427'] = 'top';
var u246 = document.getElementById('u246');
gv_vAlignTable['u246'] = 'top';
var u62 = document.getElementById('u62');

var u336 = document.getElementById('u336');

var u219 = document.getElementById('u219');

var u327 = document.getElementById('u327');

var u572 = document.getElementById('u572');

var u377 = document.getElementById('u377');
gv_vAlignTable['u377'] = 'top';
var u291 = document.getElementById('u291');

var u114 = document.getElementById('u114');

var u57 = document.getElementById('u57');

var u169 = document.getElementById('u169');

var u231 = document.getElementById('u231');

var u610 = document.getElementById('u610');

var u619 = document.getElementById('u619');
gv_vAlignTable['u619'] = 'center';
var u460 = document.getElementById('u460');

var u187 = document.getElementById('u187');

var u507 = document.getElementById('u507');
gv_vAlignTable['u507'] = 'top';
var u485 = document.getElementById('u485');
gv_vAlignTable['u485'] = 'top';
var u38 = document.getElementById('u38');
gv_vAlignTable['u38'] = 'center';
var u70 = document.getElementById('u70');

var u132 = document.getElementById('u132');
gv_vAlignTable['u132'] = 'top';
var u218 = document.getElementById('u218');
gv_vAlignTable['u218'] = 'top';
var u478 = document.getElementById('u478');

var u362 = document.getElementById('u362');

var u490 = document.getElementById('u490');

var u389 = document.getElementById('u389');
gv_vAlignTable['u389'] = 'top';
var u367 = document.getElementById('u367');
gv_vAlignTable['u367'] = 'top';
var u589 = document.getElementById('u589');
gv_vAlignTable['u589'] = 'top';
var u99 = document.getElementById('u99');
gv_vAlignTable['u99'] = 'top';
var u349 = document.getElementById('u349');
gv_vAlignTable['u349'] = 'top';
var u521 = document.getElementById('u521');
gv_vAlignTable['u521'] = 'top';
var u168 = document.getElementById('u168');
gv_vAlignTable['u168'] = 'center';
var u230 = document.getElementById('u230');
gv_vAlignTable['u230'] = 'top';
var u127 = document.getElementById('u127');

var u506 = document.getElementById('u506');

var u484 = document.getElementById('u484');

var u32 = document.getElementById('u32');
gv_vAlignTable['u32'] = 'center';
var u244 = document.getElementById('u244');
gv_vAlignTable['u244'] = 'top';
var u601 = document.getElementById('u601');
gv_vAlignTable['u601'] = 'top';
var u542 = document.getElementById('u542');

var u361 = document.getElementById('u361');
gv_vAlignTable['u361'] = 'top';
var u440 = document.getElementById('u440');

var u556 = document.getElementById('u556');

var u588 = document.getElementById('u588');

var u409 = document.getElementById('u409');
gv_vAlignTable['u409'] = 'top';
var u27 = document.getElementById('u27');

var u83 = document.getElementById('u83');
gv_vAlignTable['u83'] = 'top';
var u459 = document.getElementById('u459');
gv_vAlignTable['u459'] = 'top';
var u310 = document.getElementById('u310');
gv_vAlignTable['u310'] = 'top';
var u522 = document.getElementById('u522');

var u88 = document.getElementById('u88');

var u185 = document.getElementById('u185');

var u505 = document.getElementById('u505');
gv_vAlignTable['u505'] = 'top';
var u483 = document.getElementById('u483');
gv_vAlignTable['u483'] = 'top';
var u40 = document.getElementById('u40');
gv_vAlignTable['u40'] = 'center';
var u324 = document.getElementById('u324');
gv_vAlignTable['u324'] = 'top';
var u243 = document.getElementById('u243');

var u479 = document.getElementById('u479');
gv_vAlignTable['u479'] = 'top';
var u441 = document.getElementById('u441');
gv_vAlignTable['u441'] = 'top';
var u360 = document.getElementById('u360');

var u497 = document.getElementById('u497');
gv_vAlignTable['u497'] = 'top';
var u531 = document.getElementById('u531');
gv_vAlignTable['u531'] = 'top';
var u257 = document.getElementById('u257');

var u69 = document.getElementById('u69');

var u555 = document.getElementById('u555');
gv_vAlignTable['u555'] = 'top';
var u289 = document.getElementById('u289');

var u45 = document.getElementById('u45');
gv_vAlignTable['u45'] = 'center';
var u192 = document.getElementById('u192');
gv_vAlignTable['u192'] = 'center';
var u428 = document.getElementById('u428');

var u617 = document.getElementById('u617');

var u206 = document.getElementById('u206');
gv_vAlignTable['u206'] = 'top';
var u184 = document.getElementById('u184');
gv_vAlignTable['u184'] = 'top';
var u504 = document.getElementById('u504');

var u482 = document.getElementById('u482');

var u323 = document.getElementById('u323');
gv_vAlignTable['u323'] = 'top';
var u242 = document.getElementById('u242');
gv_vAlignTable['u242'] = 'top';
var u96 = document.getElementById('u96');

var u399 = document.getElementById('u399');
gv_vAlignTable['u399'] = 'top';
var u439 = document.getElementById('u439');
gv_vAlignTable['u439'] = 'top';
var u43 = document.getElementById('u43');
gv_vAlignTable['u43'] = 'center';
var u496 = document.getElementById('u496');

var u447 = document.getElementById('u447');
gv_vAlignTable['u447'] = 'top';
var u337 = document.getElementById('u337');
gv_vAlignTable['u337'] = 'top';
var u256 = document.getElementById('u256');
gv_vAlignTable['u256'] = 'top';
var u53 = document.getElementById('u53');
gv_vAlignTable['u53'] = 'center';
var u454 = document.getElementById('u454');

var u129 = document.getElementById('u129');

var u226 = document.getElementById('u226');
gv_vAlignTable['u226'] = 'top';
var u71 = document.getElementById('u71');

var u133 = document.getElementById('u133');

var u322 = document.getElementById('u322');
gv_vAlignTable['u322'] = 'top';
var u329 = document.getElementById('u329');
gv_vAlignTable['u329'] = 'top';
var u511 = document.getElementById('u511');
gv_vAlignTable['u511'] = 'top';
var u205 = document.getElementById('u205');

var u183 = document.getElementById('u183');

var u10 = document.getElementById('u10');

var u481 = document.getElementById('u481');
gv_vAlignTable['u481'] = 'top';
var u179 = document.getElementById('u179');

var u558 = document.getElementById('u558');

var u141 = document.getElementById('u141');

var u197 = document.getElementById('u197');
gv_vAlignTable['u197'] = 'top';
var u509 = document.getElementById('u509');
gv_vAlignTable['u509'] = 'top';
var u495 = document.getElementById('u495');
gv_vAlignTable['u495'] = 'top';
var u39 = document.getElementById('u39');

var u255 = document.getElementById('u255');

var u583 = document.getElementById('u583');
gv_vAlignTable['u583'] = 'top';
var u309 = document.getElementById('u309');

var u453 = document.getElementById('u453');
gv_vAlignTable['u453'] = 'top';
var u128 = document.getElementById('u128');
gv_vAlignTable['u128'] = 'top';
var u538 = document.getElementById('u538');

var u602 = document.getElementById('u602');

var u60 = document.getElementById('u60');
gv_vAlignTable['u60'] = 'top';
var u75 = document.getElementById('u75');
gv_vAlignTable['u75'] = 'top';
var u467 = document.getElementById('u467');
gv_vAlignTable['u467'] = 'top';
var u599 = document.getElementById('u599');
gv_vAlignTable['u599'] = 'top';
var u204 = document.getElementById('u204');
gv_vAlignTable['u204'] = 'top';
var u182 = document.getElementById('u182');
gv_vAlignTable['u182'] = 'top';
var u66 = document.getElementById('u66');

u66.style.cursor = 'pointer';
if (bIE) u66.attachEvent("onclick", Clicku66);
else u66.addEventListener("click", Clicku66, true);
function Clicku66(e)
{
windowEvent = e;


if (true) {

	self.location.href="消息中心（非导航项）.html" + GetQuerystring();

}

}
gv_vAlignTable['u66'] = 'top';
var u480 = document.getElementById('u480');

var u178 = document.getElementById('u178');

var u421 = document.getElementById('u421');
gv_vAlignTable['u421'] = 'top';
var u140 = document.getElementById('u140');
gv_vAlignTable['u140'] = 'top';
var u196 = document.getElementById('u196');
gv_vAlignTable['u196'] = 'center';
var u516 = document.getElementById('u516');

var u113 = document.getElementById('u113');

var u7 = document.getElementById('u7');
gv_vAlignTable['u7'] = 'center';
var u23 = document.getElementById('u23');
gv_vAlignTable['u23'] = 'center';
var u154 = document.getElementById('u154');

u154.style.cursor = 'pointer';
if (bIE) u154.attachEvent("onclick", Clicku154);
else u154.addEventListener("click", Clicku154, true);
function Clicku154(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u166','','fade',500);

}

}

var u407 = document.getElementById('u407');
gv_vAlignTable['u407'] = 'top';
var u452 = document.getElementById('u452');

var u371 = document.getElementById('u371');
gv_vAlignTable['u371'] = 'top';
var u612 = document.getElementById('u612');

var u503 = document.getElementById('u503');
gv_vAlignTable['u503'] = 'top';
var u491 = document.getElementById('u491');
gv_vAlignTable['u491'] = 'top';
var u466 = document.getElementById('u466');

var u598 = document.getElementById('u598');

var u203 = document.getElementById('u203');

var u181 = document.getElementById('u181');

var u84 = document.getElementById('u84');

var u258 = document.getElementById('u258');
gv_vAlignTable['u258'] = 'top';
var u320 = document.getElementById('u320');

var u4 = document.getElementById('u4');
gv_vAlignTable['u4'] = 'center';
var u217 = document.getElementById('u217');

var u195 = document.getElementById('u195');

var u65 = document.getElementById('u65');
gv_vAlignTable['u65'] = 'center';
var u493 = document.getElementById('u493');
gv_vAlignTable['u493'] = 'top';
var u73 = document.getElementById('u73');
gv_vAlignTable['u73'] = 'top';
var u334 = document.getElementById('u334');

var u153 = document.getElementById('u153');

u153.style.cursor = 'pointer';
if (bIE) u153.attachEvent("onclick", Clicku153);
else u153.addEventListener("click", Clicku153, true);
function Clicku153(e)
{
windowEvent = e;


if (true) {

	SetPanelVisibility('u190','','fade',500);

}

}

var u451 = document.getElementById('u451');
gv_vAlignTable['u451'] = 'top';
if (window.OnLoad) OnLoad();
